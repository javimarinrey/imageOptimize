- download ImageMagick (https://www.imagemagick.org/download/binaries/ImageMagick-7.0.5-10-Q16-HDRI-x64-dll.exe)
- path environment ImageMagick

npm install request
npm install gm